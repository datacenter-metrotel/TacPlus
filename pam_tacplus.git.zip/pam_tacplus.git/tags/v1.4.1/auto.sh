#!/bin/sh

autoreconf -f -v -i
