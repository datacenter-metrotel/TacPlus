#!/bin/sh

autoreconf -I m4 -i
